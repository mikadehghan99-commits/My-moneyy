My Money Pro v1
نسخه کامل‌تر اپ حساب‌وکتاب شخصی.
فایل‌های index.html، manifest.json و sw.js را در ریشه سایت قرار دهید.
برای نصب به‌صورت Web App، سایت باید با HTTPS منتشر شود و سپس در Safari گزینه Add to Home Screen انتخاب شود.
